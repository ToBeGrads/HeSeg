// src/components/Viewer/MosaicView.tsx
import { useViewerStore } from '../../store/useViewerStore'

interface MosaicViewProps {
  slices: any[]
}

export function MosaicView({ slices }: MosaicViewProps) {
  // ✨ Get state directly from store
  const { currentSlices, setCurrentSlice } = useViewerStore()
  const currentSlice = currentSlices.axial

  const totalItems = Math.min(30, slices.length)
  const startIndex = Math.max(0, currentSlice - Math.floor(totalItems / 2))

  const handleSliceClick = (index: number) => {
    setCurrentSlice('axial', index)
  }

  return (
    <div className="mosaic-view">
      <div className="mosaic-header">
        <h3>Axial Slices</h3>
        <span>Showing {totalItems} of {slices.length}</span>
      </div>
      <div className="mosaic-grid">
        {Array.from({ length: totalItems }, (_, i) => {
          const sliceIndex = startIndex + i
          if (sliceIndex >= slices.length) return null

          const slice = slices[sliceIndex]
          const isActive = sliceIndex === currentSlice

          return (
            <div
              key={sliceIndex}
              className={`mosaic-item ${isActive ? 'active' : ''}`}
              onClick={() => handleSliceClick(sliceIndex)}
            >
              {slice?.canvas && (
                <img
                  src={slice.canvas.toDataURL()}
                  alt={`Axial ${sliceIndex + 1}`}
                  className="mosaic-image"
                />
              )}
              <div className="mosaic-label">{sliceIndex + 1}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}